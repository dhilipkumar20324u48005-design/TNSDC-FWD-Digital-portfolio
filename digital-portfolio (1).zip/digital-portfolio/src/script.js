// Animate skill bars on scroll
const fills = document.querySelectorAll('.fill');

window.addEventListener('scroll', () => {
  fills.forEach(fill => {
    const position = fill.getBoundingClientRect().top;
    if (position < window.innerHeight - 100) {
      fill.style.width = fill.getAttribute('data-width');
    }
  });
});
